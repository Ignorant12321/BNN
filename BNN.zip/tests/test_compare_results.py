import csv
from pathlib import Path

import yaml

from src.experiments.compare_results import run_compare_results


def _write_metrics(run_dir: Path, rmse: float, nll: float) -> None:
    metrics_dir = run_dir / "metrics"
    metrics_dir.mkdir(parents=True)
    with (metrics_dir / "metrics.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["metric", "value"])
        writer.writeheader()
        writer.writerow({"metric": "rmse", "value": rmse})
        writer.writerow({"metric": "nll", "value": nll})


def test_compare_results_reads_existing_runs_without_training(tmp_path: Path):
    run_a = tmp_path / "outputs" / "improved_bnn" / "run-a"
    run_b = tmp_path / "outputs" / "cnn_baseline" / "run-b"
    _write_metrics(run_a, rmse=1.5, nll=2.5)
    _write_metrics(run_b, rmse=3.5, nll=4.5)
    config_path = tmp_path / "compare.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "name": "main",
                "output_dir": str(tmp_path / "outputs"),
                "runs": [
                    {"label": "BNN", "path": str(run_a)},
                    {"label": "CNN", "path": str(run_b)},
                ],
            }
        ),
        encoding="utf-8",
    )

    out_dir = run_compare_results(config_path)

    summary = (out_dir / "model_metrics.csv").read_text(encoding="utf-8")
    assert "BNN" in summary
    assert "CNN" in summary
    assert "1.5" in summary
    assert "4.5" in summary
