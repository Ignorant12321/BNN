# 光伏概率预测实验框架

这个项目用于做光伏功率概率预测实验。当前工程流程被拆成三步：

1. 数据预处理与切分；
2. 每次只训练一个模型，并只用 `train.csv` 拟合；
3. 单独读取已有训练结果做对比。

这样做的好处是：不同模型、不同 lookback、不同参数都能形成独立 run，后续对比不会重新训练，也更适合论文实验管理。

## 目录结构

```text
configs/
  data.yaml                 # 数据路径、窗口长度、特征列、切分比例
  models/
    bnn_1h.yaml             # BNN，过去 1h 输入
    bnn_4h.yaml             # BNN，过去 4h 输入
    bnn_8h.yaml             # BNN，过去 8h 输入
    bnn_24h.yaml            # BNN，过去 24h 输入
    mlp_24h.yaml            # MLP baseline，过去 24h 输入
    cnn_24h.yaml            # CNN baseline，过去 24h 输入
    mc_dropout_24h.yaml     # MC Dropout baseline，过去 24h 输入
  compare/
    main.yaml               # 读取已有 run，对比主模型和 baseline
    lookback.yaml           # 读取已有 run，对比 BNN 不同 lookback
src/
  config.py                 # YAML include、默认配置和配置合并
  environment.py            # PyTorch/CUDA 环境检测
  data/
    pv.py                   # 数据读取、合并、按 split 构造滑动窗口
    preprocess.py           # 原始 CSV 预处理命令
    split.py                # train/val/test 切分命令
  models/
    registry.py             # 模型注册表
    torch_models.py          # PyTorch/CUDA 模型
    improved_bnn.py         # NumPy 轻量主模型
    baselines.py            # NumPy ridge baseline
  training/
    torch_trainer.py         # PyTorch/CUDA 训练器
  experiments/
    train.py                # 单模型训练入口，读取 train/val/test split
    compare_results.py      # 只读取已有结果做对比
```

## 安装依赖

```powershell
pip install -r requirements.txt
```

## 检查 PyTorch/CUDA

```powershell
python -m src.environment
```

正常情况下会看到类似：

```text
available: True
cuda_available: True
device: cuda
cuda_device_name: NVIDIA ...
```

项目默认训练后端是 PyTorch，默认设备是 CUDA。这些默认值由 `src/config.py` 补齐，所以模型 yaml 里不用重复写：

```yaml
training:
  backend: torch
  device: cuda
```

如果需要临时改成 CPU，可以在某个模型 yaml 里覆盖：

```yaml
training:
  device: cpu
```

## 数据配置

数据默认配置在：

```text
configs/data.yaml
```

关键字段：

```yaml
data:
  lookback: 96     # 默认过去 24h，15 分钟粒度下 96 步
  horizon: 16      # 预测未来 4h，15 分钟粒度下 16 步
  features:
    history:
      - AC_POWER
    weather:
      - AMBIENT_TEMPERATURE
      - MODULE_TEMPERATURE
      - IRRADIATION
    direct:
      - AC_POWER
    target: AC_POWER
```

`history_features / weather_features / direct_features` 不需要手写，代码会根据 `data.features` 自动推断。

## 数据预处理

```powershell
python -m src.data.preprocess --config configs/data.yaml
```

输出：

```text
data/processed/plant_frame.csv
```

## 划分训练集、验证集、测试集

```powershell
python -m src.data.split --config configs/data.yaml
```

输出：

```text
data/processed/train.csv
data/processed/val.csv
data/processed/test.csv
```

切分按时间顺序完成，不会随机打乱。训练入口会直接读取这三个文件；如果原始 CSV 存在但缺少任意 split 文件，训练会报错并提示先运行预处理和切分命令。

## 训练单个模型

每个 `configs/models/*.yaml` 都是一份单模型训练配置。训练前请先完成：

```powershell
python -m src.data.preprocess --config configs/data.yaml
python -m src.data.split --config configs/data.yaml
```

项目当前没有 `configs/default.yaml`。单模型训练命令应使用 `configs/models/` 下的具体模型配置。

训练时数据流如下：

```text
data/processed/train.csv -> 构造 train 窗口 -> 拟合模型
data/processed/val.csv   -> 构造 val 窗口   -> 评估
data/processed/test.csv  -> 构造 test 窗口  -> 最终评估
```

为了避免数据泄露，`train`、`val`、`test` 会在各自 CSV 内独立构造滑动窗口。也就是说，验证集或测试集开头的窗口不会借用训练集末尾的历史行。

训练 BNN 24h：

```powershell
python -m src.experiments.train --config configs/models/bnn_24h.yaml
```

训练 BNN 不同 lookback：

```powershell
python -m src.experiments.train --config configs/models/bnn_1h.yaml
python -m src.experiments.train --config configs/models/bnn_4h.yaml
python -m src.experiments.train --config configs/models/bnn_8h.yaml
python -m src.experiments.train --config configs/models/bnn_24h.yaml
```

训练 baseline：

```powershell
python -m src.experiments.train --config configs/models/mlp_24h.yaml
python -m src.experiments.train --config configs/models/cnn_24h.yaml
python -m src.experiments.train --config configs/models/mc_dropout_24h.yaml
```

输出：

```text
outputs/<model_name>/<timestamp>/metrics/metrics.csv
```

`metrics.csv` 会同时写出：

```text
train_rmse, train_nll
val_rmse, val_nll
test_rmse, test_nll
rmse, nll
```

其中 `rmse` 和 `nll` 是兼容对比脚本的主指标，当前等同于 `test_rmse` 和 `test_nll`。

不同 lookback 必须分别训练，因为输入窗口长度不同，模型输入维度也不同。

## 对比已有结果

对比命令不会训练模型，只读取已有 run 目录中的 `metrics.csv`。默认用于排序和展示的 `rmse`、`nll` 是测试集指标。

先把 run 目录填入：

```text
configs/compare/main.yaml
configs/compare/lookback.yaml
```

然后运行：

```powershell
python -m src.experiments.compare_results --config configs/compare/main.yaml
python -m src.experiments.compare_results --config configs/compare/lookback.yaml
```

输出：

```text
outputs/compare/<name>-<timestamp>/model_metrics.csv
```

## 模型说明

当前 PyTorch 模型在 `src/models/torch_models.py`。

- `improved_bnn`：三分支结构，分别处理 history、weather、direct，再融合预测；
- `mlp_baseline`：使用全部输入的 PyTorch 网络；
- `cnn_baseline`：只使用历史功率输入；
- `mc_dropout`：使用历史功率和未来天气输入，并启用 dropout。

`branch_dim` 只对分支结构有意义，当前会控制 history/weather/direct 分支输出维度：

```yaml
model:
  name: improved_bnn
  hidden_dim: 128
  branch_dim: 64
```

## 配置 include

模型配置可以引用数据配置：

```yaml
include:
  - ../data.yaml

data:
  lookback: 4

model:
  name: improved_bnn
```

`include` 中的配置先加载，当前文件中的字段会覆盖它。

## 测试

```powershell
pytest -q
```
