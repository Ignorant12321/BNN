# 光伏功率概率预测实验框架

本项目用于做光伏功率预测实验。当前流程分为三步：先把原始 CSV 预处理并按时间切分，再按单个 YAML 配置训练一个模型，最后加载已训练产物做统一评估和对比。

训练阶段只使用 `train` 拟合模型，并输出 `train/val` 指标；`test` 指标只在 `compare` 阶段统一计算。这样可以避免在调参时反复使用测试集。

## 环境

```powershell
pip install -r requirements.txt
```

可选：检查 PyTorch 和 CUDA 状态。

```powershell
python -m src.environment
```

项目默认训练后端是 `torch`，设备是 `auto`。`auto` 会优先使用 CUDA，没有可用 CUDA 时使用 CPU。也可以在模型配置里固定设备：

```yaml
training:
  device: cpu
```

## 目录结构

```text
configs/
  data.yaml                 # 原始数据路径、切分比例、窗口长度、特征列
  models/
    bnn/
      bnn.yaml              # improved_bnn 默认配置
      1h.yaml               # 只覆盖 lookback=4
      4h.yaml               # 只覆盖 lookback=16
      8h.yaml               # 只覆盖 lookback=32
      12h.yaml              # 只覆盖 lookback=48
      24h.yaml              # 使用默认 lookback=96
    mlp/
      mlp.yaml              # mlp_baseline 默认配置
      24h.yaml
    cnn/
      cnn.yaml              # cnn_baseline 默认配置
      24h.yaml
    mc_dropout/
      mc_dropout.yaml       # mc_dropout 默认配置
      24h.yaml
  compare/
    main.yaml               # 主模型和 baseline 对比
    lookback.yaml           # improved_bnn 不同 lookback 对比
src/
  data/                     # 预处理、切分、滑动窗口构造
  models/                   # 模型注册表、PyTorch 模型、NumPy fallback
  training/                 # 训练流程和 PyTorch 训练器
  evaluation/               # 指标、预测导出、图表、统一评估
  artifacts/                # 训练/对比产物读写
  experiments/
    train.py                # 单模型训练入口
    compare.py              # 已训练产物对比入口
```

## 数据流程

原始数据默认放在 `dataset/`：

```text
dataset/Plant_1_Generation_Data.csv
dataset/Plant_1_Weather_Sensor_Data.csv
```

预处理会按 `DATE_TIME` 聚合发电数据，聚合方式是 `DC_POWER/AC_POWER/DAILY_YIELD/TOTAL_YIELD` 求和；天气数据按同一时间戳求均值；两者 inner join 后写出：

```powershell
python -m src.data.preprocess --config configs/data.yaml
```

输出：

```text
data/processed/plant_frame.csv
```

然后按时间顺序切分，不随机打乱：

```powershell
python -m src.data.split --config configs/data.yaml
```

输出：

```text
data/processed/train.csv
data/processed/val.csv
data/processed/test.csv
```

训练入口要求这些 split 文件已经存在。如果原始 CSV 存在但 split 缺失，程序会报错并提示先运行预处理和切分命令。

## 窗口和特征

`configs/data.yaml` 中的默认任务是 15 分钟粒度下，用过去 24 小时预测未来 4 小时：

```yaml
data:
  lookback: 96
  horizon: 16
  features:
    history:
      - AC_POWER
    weather:
      - AMBIENT_TEMPERATURE
      - MODULE_TEMPERATURE
      - IRRADIATION
    direct:
      - AC_POWER
    target: AC_POWER
```

每个 split 会独立构造滑动窗口，不会让验证集或测试集开头的窗口借用前一个 split 末尾的历史行。单个窗口含义如下：

```text
history: 过去 lookback 步的历史特征
weather: 未来 horizon 步的天气特征
direct : 预测起点前一时刻的直接特征
target : 未来 horizon 步的 AC_POWER
```

常用 lookback 配置：

```text
1h  = 4
4h  = 16
8h  = 32
12h = 48
24h = 96
```

## 训练

每次训练一个模型：

```powershell
python -m src.experiments.train --config configs/models/bnn/24h.yaml
```

训练不同 lookback 的 improved_bnn：

```powershell
python -m src.experiments.train --config configs/models/bnn/1h.yaml
python -m src.experiments.train --config configs/models/bnn/4h.yaml
python -m src.experiments.train --config configs/models/bnn/8h.yaml
python -m src.experiments.train --config configs/models/bnn/12h.yaml
python -m src.experiments.train --config configs/models/bnn/24h.yaml
```

训练 24h baseline：

```powershell
python -m src.experiments.train --config configs/models/mlp/24h.yaml
python -m src.experiments.train --config configs/models/cnn/24h.yaml
python -m src.experiments.train --config configs/models/mc_dropout/24h.yaml
```

训练产物目录：

```text
outputs/train/<model_name>/<timestamp>/
  config.yaml
  manifest.json
  train.log
  metrics/epoch_history.csv
  metrics/split_metrics.csv
  figures/loss_curve.png
  models/best.pt             # torch 后端
  models/best.pkl            # numpy 后端
```

`split_metrics.csv` 只包含 `train` 和 `val` 指标。指标包括：

```text
mae, rmse, nmae, nrmse, picp_90, pinaw_90, picp_95, pinaw_95
```

## 模型配置

模型通过 `model.name` 从注册表构造。当前支持：

```text
improved_bnn
mlp_baseline
cnn_baseline
mc_dropout
```

当前 `configs/models/*/*.yaml` 都使用 torch 后端。torch 后端统一构造 `TorchPVNet`，区别主要来自输入分支：

```text
improved_bnn : history + future weather + direct
mlp_baseline : history + future weather + direct
cnn_baseline : history
mc_dropout   : history + future weather，并启用 dropout
```

如果把 `training.backend` 改成 `numpy`，注册表会构造轻量 ridge regression 版本，用于测试或无 PyTorch 场景。

常调字段：

```yaml
model:
  hidden_dim: 128
  branch_dim: 64
  dropout: 0.2       # 仅 mc_dropout 使用

training:
  epochs: 50
  batch_size: 64
  lr: 0.0005
  weight_decay: 0.0001
```

## 对比评估

对比命令不会重新训练模型。它会加载训练目录中的 best 模型，在指定 split 上重新预测并计算指标，默认 split 是 `test`。

使用 YAML：

```powershell
python -m src.experiments.compare --config configs/compare/main.yaml
python -m src.experiments.compare --config configs/compare/lookback.yaml
```

也可以直接从命令行传入训练产物：

```powershell
python -m src.experiments.compare --run BNN-24h=outputs/train/improved_bnn/20260521-105753
python -m src.experiments.compare --name lookback --run outputs/train/improved_bnn
python -m src.experiments.compare --name main --run BNN-24h=outputs/train/improved_bnn/20260521-105753 --run outputs/train/mlp_baseline
```

当路径指向单个训练目录，例如 `outputs/train/improved_bnn/20260521-105753`，只评估这一份训练产物。写成 `label=path` 时会使用 `label` 作为显示名。

当路径指向模型根目录，例如 `outputs/train/improved_bnn`，程序会自动展开其下所有训练目录逐个对比，默认 label 使用每个训练目录名。因此你可以把时间戳目录改名为 `1h`、`4h`、`best-24h` 这类更可读的名字，再直接对比整个模型根目录：

```yaml
runs:
  - path: outputs/train/improved_bnn
```

如果需要自定义 label，请在 YAML 中逐个列出具体训练目录：

```yaml
runs:
  - label: BNN-24h
    path: outputs/train/improved_bnn/best-24h
```

对比产物目录：

```text
outputs/comparisons/<timestamp>/
  compare_config.yaml
  model_metrics.csv
  predictions/<label>.csv
  figures/metrics_<metric>.png
  figures/loss_curves.png
  figures/prediction_0800_1200.png
  figures/prediction_1000_1400.png
  figures/prediction_1200_1600.png
  report.md
```

旧入口 `src.experiments.compare_results` 已删除，请使用 `src.experiments.compare`。

## 配置 include

模型配置通常 include 公共数据配置：

```yaml
include:
  - bnn.yaml

data:
  lookback: 48
```

include 文件先加载，当前 YAML 中的同名字段会覆盖 include 中的值。模型族默认配置放在同目录的 `<model>.yaml` 中，例如 `configs/models/bnn/bnn.yaml`；具体实验文件只写差异字段。

## 建议实验顺序

1. 先运行预处理和切分。
2. 固定 `lookback=96`，训练 `improved_bnn` 和三个 baseline。
3. 用 `configs/compare/main.yaml` 做 24h 主模型和 baseline 对比。
4. 分别训练 `1h/4h/8h/12h/24h` 的 `improved_bnn`。
5. 用 `configs/compare/lookback.yaml` 做不同历史窗口对比。
6. 只用 `train/val` 调参，最后再用 `test` 结果写最终对比。

## 测试

```powershell
pytest -q
```
