"""已有训练结果对比入口。

功能：
    只读取多个 run 目录中的 metrics.csv，汇总成新的 model_metrics.csv。
    本命令不负责训练模型。

使用：
    python -m src.experiments.compare_results --config configs/compare/main.yaml
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime
from pathlib import Path
from typing import Any

from src.config import load_config


def main() -> None:
    """命令行入口。"""
    parser = argparse.ArgumentParser(description="汇总已有训练结果，不启动训练。")
    parser.add_argument("--config", default="configs/compare/main.yaml", help="结果对比配置文件")
    args = parser.parse_args()
    out_dir = run_compare_results(args.config)
    print(f"对比结果已保存到: {out_dir / 'model_metrics.csv'}")


def run_compare_results(config_path: str | Path) -> Path:
    """读取配置中的 run 目录并生成对比汇总表。"""
    config = load_config(config_path)
    runs = parse_runs(config)
    out_dir = create_compare_results_dir(config)
    rows = []
    for run in runs:
        run_path = Path(run["path"])
        row = {
            "label": str(run["label"]),
            "run_dir": str(run_path),
            "model": run_path.parent.name,
        }
        row.update(read_metrics(run_path / "metrics" / "metrics.csv"))
        rows.append(row)
    write_summary(out_dir / "model_metrics.csv", rows)
    return out_dir


def parse_runs(config: dict[str, Any]) -> list[dict[str, str]]:
    """解析 compare 配置中的 runs 列表。"""
    runs = config.get("runs")
    if not isinstance(runs, list) or not runs:
        raise ValueError("runs must be a non-empty list")
    parsed = []
    for index, run in enumerate(runs):
        if not isinstance(run, dict):
            raise ValueError(f"runs[{index}] must be a mapping")
        label = run.get("label")
        path = run.get("path")
        if not isinstance(label, str) or not label.strip():
            raise ValueError(f"runs[{index}].label must be a non-empty string")
        if not isinstance(path, str) or not path.strip():
            raise ValueError(f"runs[{index}].path must be a non-empty string")
        parsed.append({"label": label.strip(), "path": path.strip()})
    return parsed


def create_compare_results_dir(config: dict[str, Any]) -> Path:
    """创建本次结果对比输出目录。"""
    name = str(config.get("name", "comparison")).strip() or "comparison"
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = Path(config.get("output_dir", "outputs")) / "compare" / f"{name}-{timestamp}"
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def read_metrics(path: Path) -> dict[str, str]:
    """读取单次训练输出的 metrics.csv。"""
    if not path.is_file():
        raise FileNotFoundError(f"metrics file not found: {path}")
    metrics: dict[str, str] = {}
    with path.open("r", encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            metrics[str(row["metric"])] = str(row["value"])
    return metrics


def write_summary(path: Path, rows: list[dict[str, str]]) -> None:
    """写出对比汇总 CSV。"""
    fields = ["label", "model", "run_dir"]
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()

