"""单模型训练入口。

功能：
    读取配置和已切分的 train/val/test CSV，在 train split 上拟合模型，
    分别评估 train/val/test，并输出 metrics.csv。

使用：
    python -m src.experiments.train --config configs/models/bnn_24h.yaml
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from src.config import load_config
from src.data.pv import load_split_window_arrays_from_config
from src.models.registry import build_model
from src.training.torch_trainer import evaluate_torch_model, train_torch_model


def main() -> None:
    """命令行入口。"""
    parser = argparse.ArgumentParser(description="Train one PV forecasting model.")
    parser.add_argument("--config", default="configs/models/bnn_24h.yaml")
    args = parser.parse_args()
    run_training(load_config(args.config))


def run_training(config: dict[str, Any]) -> Path:
    """执行一次单模型训练：只用 train split 拟合，使用各 split 评估。"""
    model = build_model(config)
    run_dir = create_run_dir(config)
    arrays_by_split = load_or_make_split_arrays(config)
    train_arrays = arrays_by_split["train"]
    if getattr(model, "is_torch_model", False):
        train_torch_model(model, train_arrays, config)
        metrics = evaluate_splits(model, arrays_by_split, evaluate_torch_model)
    elif hasattr(model, "fit"):
        model.fit(train_arrays)
        metrics = evaluate_splits(model, arrays_by_split, evaluate_model)
    else:
        metrics = evaluate_splits(model, arrays_by_split, evaluate_model)

    metrics_dir = run_dir / "metrics"
    metrics_dir.mkdir(parents=True, exist_ok=True)
    with (metrics_dir / "metrics.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["metric", "value"])
        writer.writeheader()
        for metric, value in metrics.items():
            writer.writerow({"metric": metric, "value": value})
    return run_dir


def evaluate_model(model, arrays) -> dict[str, float]:
    """在传入 split 的全部窗口上评估拟合后的模型。"""
    mean, log_var = model(arrays.as_batch())
    target = arrays.target[: len(mean)]
    rmse = float(np.sqrt(np.mean((mean - target) ** 2)))
    nll = float(np.mean(log_var + (target - mean) ** 2 / np.exp(log_var)))
    return {"rmse": rmse, "nll": nll}


def evaluate_splits(model, arrays_by_split: dict[str, Any], evaluator) -> dict[str, float]:
    """分别评估 train/val/test，并保留 test 指标作为主指标。"""
    metrics: dict[str, float] = {}
    for split_name in ("train", "val", "test"):
        split_metrics = evaluator(model, arrays_by_split[split_name])
        for metric_name, value in split_metrics.items():
            metrics[f"{split_name}_{metric_name}"] = value
    metrics["rmse"] = metrics["test_rmse"]
    metrics["nll"] = metrics["test_nll"]
    return metrics


def load_or_make_split_arrays(config: dict[str, Any]) -> dict[str, Any]:
    """优先读取已切分 CSV；真实数据存在但未切分时拒绝全量训练以避免泄露。"""
    data = config.get("data", {})
    processed_dir = Path(data.get("processed_dir", "data/processed"))
    split_paths = {split_name: processed_dir / f"{split_name}.csv" for split_name in ("train", "val", "test")}
    existing_splits = [path for path in split_paths.values() if path.is_file()]
    if len(existing_splits) == len(split_paths):
        return load_split_window_arrays_from_config(config)

    generation_path = Path(data.get("generation_path", ""))
    weather_path = Path(data.get("weather_path", ""))
    if generation_path.is_file() and weather_path.is_file():
        missing = ", ".join(str(path) for path in split_paths.values() if not path.is_file())
        raise FileNotFoundError(
            "missing split CSV files; run `python -m src.data.preprocess --config configs/data.yaml` "
            f"and `python -m src.data.split --config configs/data.yaml` first. Missing: {missing}"
        )
    smoke = make_smoke_arrays(config)
    return {"train": smoke, "val": smoke, "test": smoke}


def create_run_dir(config: dict[str, Any]) -> Path:
    model_name = str(config.get("model", {}).get("name", "model"))
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir = Path(config.get("output_dir", "outputs")) / model_name / timestamp
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def make_smoke_arrays(config: dict[str, Any]):
    """在无真实数据的测试/冒烟场景下构造确定性零数组。"""
    from src.data.pv import WindowArrays, feature_dimensions_from_config

    data = config["data"]
    history_features, weather_features, direct_features = feature_dimensions_from_config(config)
    batch_size = int(config.get("training", {}).get("batch_size", 4))
    horizon = int(data["horizon"])
    return WindowArrays(
        history=np.zeros((batch_size, int(data["lookback"]), history_features), dtype=np.float32),
        weather=np.zeros((batch_size, horizon, weather_features), dtype=np.float32),
        direct=np.zeros((batch_size, direct_features), dtype=np.float32),
        target=np.zeros((batch_size, horizon), dtype=np.float32),
    )


if __name__ == "__main__":
    main()
